/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iqe_ra1_p03;
// IMPORTS NECESSARIS
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
/**
 *
 * @author AluCiclesGS1
 */
public class IQE_RA1_P03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, Exception {
        // TODO code application logic here
        int opcio = 0;
        Scanner teclado = new Scanner(System.in); //Creem objecte de escáner o lectura
        while (opcio < 4) {
            menu();
            System.out.println("  --Escull opció: ");
            opcio = teclado.nextInt(); //cridem metode nextInt per llegar el numero i guardar a opcio.
            Seleccio(opcio); //Executem exercici escollit.
        }
    }
    
    private static void menu() {
        System.out.println("|===========================================|");
        System.out.println("|****************** MENÚ *******************|");
        System.out.println("|===========================================|");
        System.out.println("|      1.- Mostrar dades Clash Royale       |");
        System.out.println("|-------------------------------------------|");
        System.out.println("|     2.- Trobar jugador amb més copes      |");
        System.out.println("|-------------------------------------------|");
        System.out.println("|   3.- Trobar temperatura més alta/baixa   |");
        System.out.println("|-------------------------------------------|");
        System.out.println("|               4.- Sortir                  |");
        System.out.println("|===========================================|");
    }
    
    private static void Seleccio(int opcio) throws IOException, Exception {
        switch (opcio) {

            case 1:
                exercici1();
                break;
            case 2:
                exercici2();
                break;
            case 3:
                exercici3();
                break;
            default:
                break;

        }
    }
    
    //exercici 2
    public static void exercici1() throws Exception {
        Document doc = obrirFitxerXML("./clash.xml");       //Busca l'arxiu
        NodeList jugs = doc.getElementsByTagName("Jugador");        //Troba l'element jugador com a llistat
        for (int i = 0; i < jugs.getLength(); i++) {    
            Element jug = (Element) jugs.item(i);   //Es crea per buscar els elements de cada un dels jugadors
            System.out.println(jug.getElementsByTagName("Nom").item(0).getTextContent());   //Retorna el nom del jugador
            System.out.println("    Nivell : " + jug.getElementsByTagName("Nivell").item(0).getTextContent());  //Retorna el seu nivell
            System.out.println("    Copes : " + jug.getElementsByTagName("Copes").item(0).getTextContent());    //Retorna les copes
            System.out.println("    Or : " + jug.getElementsByTagName("Oro").item(0).getTextContent());     //Retorna quant d'or te el jugador
            System.out.println("    Gemes : " + jug.getElementsByTagName("Gemes").item(0).getTextContent());    //Retorna les gemes que te 
            System.out.println("    Estrelles : " + jug.getElementsByTagName("Estrelles").item(0).getTextContent() + "\n");    //Retorna les seves estrelles
            NodeList partides = jug.getElementsByTagName("Partida");       //Es crea una nova llista per a les partides
            for (int y = 0; y < partides.getLength(); y++) {
                Element partida = (Element) partides.item(y);   //Es crea per buscar els elements de cada un de les partides
                System.out.println("Partida " + (y + 1));   //Text per mostrar quina partida es la jugada
                System.out.println("    Data : " + partida.getElementsByTagName("Data").item(0).getTextContent());  //Mostra la data de quan s'ha jugat
                System.out.println("    Resultat : " + partida.getElementsByTagName("Resultat").item(0).getTextContent());  //Mostra el resultat de la partida
                System.out.println("    Temps: " + partida.getElementsByTagName("Durada").item(0).getTextContent());    //Mostra quant ha durat la partida
                System.out.println("    Tipus de partida : " + partida.getElementsByTagName("Tipus").item(0).getTextContent() + "\n");  //Mostra el tipus de partida jugada
            }
            System.out.println("\n" + "\n");    //Deixa una separacio entre jugador i jugador
        }
    }

    //exercici 3
    private static void exercici2() throws Exception {
        Document doc = obrirFitxerXML("./clash.xml");   //Busca l'arxiu
        int CopesMax = 0;   //Es dona valor a la variable de copes maximes
        NodeList listJugs = doc.getElementsByTagName("Jugador");        //Troba l'element jugador com a llistat
        Element maxCopJug = null;     //S'indica que el jugador amb mes copes es null (s'indicara mes tard)
        for (int i = 0; i < listJugs.getLength(); i++) {
            Element jug = (Element) listJugs.item(i);   //Es crea per buscar els elements de cada un dels jugadors
            int Copes = Integer.parseInt(jug.getElementsByTagName("Copes").item(0).getTextContent());   //S'indica una variable int com a copes per poder comparar
            if (Copes > CopesMax) {     //Es compara si Copes es major a la quantitat anterior ment guardat
                CopesMax = Copes;       //Si es major guarda aquest nou numero de copes com el nou CopesMax
                maxCopJug = jug;        //Guarda també quin es el jugador que té més copes
            }
        }
        System.out.println("El jugador amb més copes es " + maxCopJug.getElementsByTagName("Nom").item(0).getTextContent());   //Retorna el nom del jugador
        System.out.println("Té " + maxCopJug.getElementsByTagName("Copes").item(0).getTextContent() + " Copes");    //Retorna les copes
    }
    
    //exercici4
    private static void exercici3() throws Exception {
        for (int i = 0; i < 3; i++) {
            Document doc = obrirFitxerXML("./meteo" + (2015 + i) + ".xml");   //Busca l'arxiu
            double TempMax = 0;     //S'indica una temperatura maxima baixa per a poder guardar numeros alts despres
            double TempMin = 100;       //Al contrari en aquest es posa temperatura molt alta
            NodeList listTemp = doc.getElementsByTagName("element");        //Troba l'element element com a llistat
            Element maxTempsCal = null;     //Variables per guardar on es troba la temperatura mes alta del any
            Element maxTempsFred = null;    //Variables per guardar on es troba la temperatura mes baixa del any
            
            for (int y = 0; y < listTemp.getLength(); y++) {
                Element TempsList = (Element) listTemp.item(i);     //Es crea per buscar els elements de cada un de les diferents temperatures
                if (TempsList.getElementsByTagName("tmax").getLength() > 0) {   //Detecta si el NULL
                    double TMax = NumberFormat.getInstance().parse(TempsList.getElementsByTagName("tmax").item(0).getTextContent()).doubleValue();  //Busca la temperatura maxima
                    if (TMax > TempMax) {     
                        TempMax = TMax;       //La guarda en TempMax per comparar
                        maxTempsCal = TempsList;    //Guarda quin de la llista es el de la temperatura mes alta
                    }
                }
                if (TempsList.getElementsByTagName("tmin").getLength() > 0) {   //Detecta si el NULL
                    double TMin = NumberFormat.getInstance().parse(TempsList.getElementsByTagName("tmin").item(0).getTextContent()).doubleValue();  //Busca la temperatura minima
                    if (TMin < TempMin) {     
                        TempMin = TMin;       //La guarda en TempMin per comparar
                        maxTempsFred = TempsList;   //Guarda quin de la llista es el de la temperatura mes baixa
                    }
                }
            }
            System.out.println("./meteo" + (2015 + i) + ".xml");    //Mostra quin XML es
            System.out.println("Tmax |" + maxTempsCal.getElementsByTagName("fecha").item(0).getTextContent() + " " + maxTempsCal.getElementsByTagName("horatmax").item(0).getTextContent() + "| = " +  maxTempsCal.getElementsByTagName("tmax").item(0).getTextContent() + "C");    //La temperatura maxima
            System.out.println("Tmin |" + maxTempsFred.getElementsByTagName("fecha").item(0).getTextContent() + " " + maxTempsFred.getElementsByTagName("horatmin").item(0).getTextContent() + "| = " +  maxTempsFred.getElementsByTagName("tmin").item(0).getTextContent() + "C");     //La temperatura minima
        }
    }
    
    
    public static Document obrirFitxerXML(String fitxerXML) throws Exception {
        File fxml = new File(fitxerXML);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = (Document) dBuilder.parse(fxml);
        doc.getDocumentElement().normalize();
        return doc;
    }
}
